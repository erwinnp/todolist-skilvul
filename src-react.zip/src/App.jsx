import Todos from './components/Todos';

const App = () => {
  return (
    <>
      <Todos />
    </>
  );
};

export default App;
